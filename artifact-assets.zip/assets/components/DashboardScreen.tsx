/**
 * DashboardScreen.tsx
 * ===================
 * Neumorphic Cape Town GIS Dashboard
 * 
 * Features:
 * - 3-column responsive grid
 * - Neumorphic data cards
 * - Flight tracking widget
 * - Map preview widget
 * - Data analytics panels
 * - Turtle mascot in corner badge
 * 
 * Stitch ID: dashboard-screen-v1
 * Created: 2025-03-10
 */

import React, { useState } from 'react';

interface DashboardScreenProps {
  theme?: 'light' | 'dark' | 'high-contrast';
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({
  theme = 'light',
}) => {
  const [selectedWidget, setSelectedWidget] = useState<string | null>(null);

  const themes = {
    light: {
      bg: '#f5f7fa',
      surface: '#ffffff',
      cardBg: '#ffffff',
      shadow: 'rgba(163, 177, 198, 0.15)',
      shadowInset: 'rgba(255, 255, 255, 0.5)',
      text: '#1a202c',
      textSecondary: '#718096',
      accent: '#2d9d7f',
      accentLight: '#7dd3c0',
      border: '#cbd5e0',
    },
    dark: {
      bg: '#1a202c',
      surface: '#2d3748',
      cardBg: '#374151',
      shadow: 'rgba(0, 0, 0, 0.3)',
      shadowInset: 'rgba(255, 255, 255, 0.1)',
      text: '#e2e8f0',
      textSecondary: '#a0aec0',
      accent: '#7dd3c0',
      accentLight: '#a8e6d7',
      border: '#718096',
    },
    'high-contrast': {
      bg: '#ffffff',
      surface: '#ffffff',
      cardBg: '#ffffff',
      shadow: 'none',
      shadowInset: 'none',
      text: '#000000',
      textSecondary: '#000000',
      accent: '#ff6b35',
      accentLight: '#ff6b35',
      border: '#000000',
    },
  };

  const colors = themes[theme];

  const cardShadow = {
    boxShadow:
      theme === 'high-contrast'
        ? `1px 1px 0 ${colors.border}`
        : `8px 8px 16px ${colors.shadow}, -4px -4px 12px ${colors.shadowInset}`,
  };

  const headerShadow = {
    boxShadow:
      theme === 'high-contrast'
        ? `1px 1px 0 ${colors.border}`
        : `0 4px 12px ${colors.shadow}`,
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        background: colors.bg,
        color: colors.text,
        fontFamily: '"Segoe UI", Roboto, sans-serif',
        padding: '20px',
      }}
    >
      {/* Header */}
      <header
        style={{
          background: colors.surface,
          padding: '24px',
          borderRadius: '16px',
          marginBottom: '32px',
          ...headerShadow,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '16px',
        }}
      >
        <div>
          <h1 style={{ fontSize: '28px', fontWeight: 700, margin: '0 0 4px 0' }}>
            Dashboard
          </h1>
          <p
            style={{
              fontSize: '14px',
              color: colors.textSecondary,
              margin: 0,
            }}
          >
            Cape Town GIS Platform Analytics
          </p>
        </div>

        {/* Mascot badge (top-right) */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            padding: '8px 12px',
            background: colors.cardBg,
            borderRadius: '12px',
            border: `2px solid ${colors.accentLight}`,
          }}
        >
          <span style={{ fontSize: '24px' }}>🐢</span>
          <span style={{ fontSize: '12px', fontWeight: 600, color: colors.accent }}>
            Online
          </span>
        </div>
      </header>

      {/* Metrics row */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '16px',
          marginBottom: '32px',
        }}
      >
        {[
          { label: 'Active Flights', value: '12', icon: '✈️' },
          { label: 'Data Sources', value: '8', icon: '🗂️' },
          { label: 'Map Layers', value: '5', icon: '🗺️' },
          { label: 'Users Online', value: '3', icon: '👥' },
        ].map((metric, idx) => (
          <div
            key={idx}
            style={{
              background: colors.cardBg,
              padding: '20px',
              borderRadius: '12px',
              ...cardShadow,
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              textAlign: 'center',
              border: `1px solid ${colors.border}`,
            }}
            onMouseEnter={(e) => {
              if (theme !== 'high-contrast') {
                e.currentTarget.style.transform = 'translateY(-2px)';
              }
            }}
            onMouseLeave={(e) => {
              if (theme !== 'high-contrast') {
                e.currentTarget.style.transform = 'translateY(0)';
              }
            }}
          >
            <div style={{ fontSize: '24px', marginBottom: '8px' }}>
              {metric.icon}
            </div>
            <div
              style={{
                fontSize: '28px',
                fontWeight: 700,
                marginBottom: '4px',
                color: colors.accent,
              }}
            >
              {metric.value}
            </div>
            <div
              style={{
                fontSize: '12px',
                color: colors.textSecondary,
              }}
            >
              {metric.label}
            </div>
          </div>
        ))}
      </div>

      {/* Main content grid */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))',
          gap: '20px',
        }}
      >
        {/* Flight Tracking Widget */}
        <div
          style={{
            background: colors.cardBg,
            padding: '24px',
            borderRadius: '16px',
            ...cardShadow,
            border: `1px solid ${colors.border}`,
            cursor: 'pointer',
            transition: 'all 0.2s ease',
          }}
          onClick={() => setSelectedWidget('flights')}
          onMouseEnter={(e) => {
            if (theme !== 'high-contrast') {
              e.currentTarget.style.transform = 'translateY(-2px)';
            }
          }}
          onMouseLeave={(e) => {
            if (theme !== 'high-contrast') {
              e.currentTarget.style.transform = 'translateY(0)';
            }
          }}
        >
          <h2 style={{ fontSize: '16px', fontWeight: 700, marginTop: 0 }}>
            ✈️ Active Flights
          </h2>
          <div style={{ height: '200px', background: colors.bg, borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <p style={{ color: colors.textSecondary }}>
              Cape Town Airspace (Live)
            </p>
          </div>
          <p
            style={{
              fontSize: '12px',
              color: colors.textSecondary,
              marginTop: '12px',
            }}
          >
            Last updated: 2 minutes ago
          </p>
        </div>

        {/* Map Preview Widget */}
        <div
          style={{
            background: colors.cardBg,
            padding: '24px',
            borderRadius: '16px',
            ...cardShadow,
            border: `1px solid ${colors.border}`,
            cursor: 'pointer',
            transition: 'all 0.2s ease',
          }}
          onClick={() => setSelectedWidget('map')}
          onMouseEnter={(e) => {
            if (theme !== 'high-contrast') {
              e.currentTarget.style.transform = 'translateY(-2px)';
            }
          }}
          onMouseLeave={(e) => {
            if (theme !== 'high-contrast') {
              e.currentTarget.style.transform = 'translateY(0)';
            }
          }}
        >
          <h2 style={{ fontSize: '16px', fontWeight: 700, marginTop: 0 }}>
            🗺️ Map View
          </h2>
          <div style={{ height: '200px', background: colors.bg, borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <p style={{ color: colors.textSecondary }}>
              Cape Town & Western Cape
            </p>
          </div>
          <button
            style={{
              marginTop: '12px',
              padding: '8px 16px',
              background: colors.accent,
              color: '#ffffff',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer',
              fontSize: '12px',
              fontWeight: 600,
              transition: 'all 0.2s ease',
            }}
            onMouseEnter={(e) => {
              if (theme !== 'high-contrast') {
                e.currentTarget.style.opacity = '0.8';
              }
            }}
            onMouseLeave={(e) => {
              if (theme !== 'high-contrast') {
                e.currentTarget.style.opacity = '1';
              }
            }}
          >
            Open Full Map
          </button>
        </div>

        {/* Data Sources Widget */}
        <div
          style={{
            background: colors.cardBg,
            padding: '24px',
            borderRadius: '16px',
            ...cardShadow,
            border: `1px solid ${colors.border}`,
          }}
        >
          <h2 style={{ fontSize: '16px', fontWeight: 700, marginTop: 0 }}>
            🗂️ Data Sources
          </h2>
          <div>
            {['OpenSky ADS-B', 'Satellite Imagery', 'Weather API', 'User Data'].map(
              (source, idx) => (
                <div
                  key={idx}
                  style={{
                    padding: '12px 0',
                    borderBottom:
                      idx < 3 ? `1px solid ${colors.border}` : 'none',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                  }}
                >
                  <span style={{ fontSize: '13px' }}>{source}</span>
                  <span
                    style={{
                      fontSize: '11px',
                      padding: '4px 8px',
                      background: colors.bg,
                      borderRadius: '4px',
                      color: colors.accent,
                      fontWeight: 600,
                    }}
                  >
                    LIVE
                  </span>
                </div>
              )
            )}
          </div>
        </div>

        {/* Analytics Panel */}
        <div
          style={{
            background: colors.cardBg,
            padding: '24px',
            borderRadius: '16px',
            ...cardShadow,
            border: `1px solid ${colors.border}`,
          }}
        >
          <h2 style={{ fontSize: '16px', fontWeight: 700, marginTop: 0 }}>
            📊 Weekly Analytics
          </h2>
          <div style={{ display: 'flex', gap: '12px', justifyContent: 'space-around' }}>
            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, idx) => (
              <div
                key={idx}
                style={{
                  flex: 1,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                }}
              >
                <div
                  style={{
                    width: '8px',
                    height: `${40 + Math.random() * 80}px`,
                    background: colors.accent,
                    borderRadius: '4px',
                    marginBottom: '8px',
                  }}
                />
                <span style={{ fontSize: '11px', color: colors.textSecondary }}>
                  {day}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div
          style={{
            background: colors.cardBg,
            padding: '24px',
            borderRadius: '16px',
            ...cardShadow,
            border: `1px solid ${colors.border}`,
            gridColumn: 'span 1',
          }}
        >
          <h2 style={{ fontSize: '16px', fontWeight: 700, marginTop: 0 }}>
            🚀 Quick Actions
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {['Upload Dataset', 'Start Flight Tracking', 'Create Report'].map(
              (action, idx) => (
                <button
                  key={idx}
                  style={{
                    padding: '12px 16px',
                    background: colors.bg,
                    border: `2px solid ${colors.accent}`,
                    borderRadius: '8px',
                    color: colors.accent,
                    cursor: 'pointer',
                    fontSize: '13px',
                    fontWeight: 600,
                    transition: 'all 0.2s ease',
                  }}
                  onMouseEnter={(e) => {
                    if (theme !== 'high-contrast') {
                      e.currentTarget.style.background = colors.accent;
                      e.currentTarget.style.color = '#ffffff';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (theme !== 'high-contrast') {
                      e.currentTarget.style.background = colors.bg;
                      e.currentTarget.style.color = colors.accent;
                    }
                  }}
                >
                  {action}
                </button>
              )
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer
        style={{
          marginTop: '40px',
          padding: '16px 24px',
          background: colors.cardBg,
          borderRadius: '12px',
          border: `1px solid ${colors.border}`,
          textAlign: 'center',
          color: colors.textSecondary,
          fontSize: '12px',
        }}
      >
        Cape Town GIS Platform • Built with Neumorphic Whimsy • 🐢✨
      </footer>

      <style>{`
        @media (prefers-reduced-motion: reduce) {
          * {
            animation: none !important;
            transition: none !important;
          }
        }

        @media (max-width: 768px) {
          div[style*="grid-template-columns"] {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </div>
  );
};

export default DashboardScreen;
