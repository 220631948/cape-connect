/**
 * LoginScreen.tsx
 * ===============
 * Neumorphic + Whimsical Login Screen
 * 
 * Design System: Talph's Whimsical Neumorphism v1
 * - Soft shadows (blur 14px, spread 2px)
 * - Beveled input fields
 * - Extruded primary button (lifts on hover)
 * - Mascot peeks from top-right
 * - Accessibility: Light, Dark, High-Contrast variants
 * 
 * Stitch ID: login-screen-v1
 * Created: 2025-03-10
 */

import React, { useState, useEffect } from 'react';

interface LoginScreenProps {
  theme?: 'light' | 'dark' | 'high-contrast';
  onLogin?: (email: string, password: string) => void;
  showMascot?: boolean;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  theme = 'light',
  onLogin,
  showMascot = true,
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [mascotPose, setMascotPose] = useState('default');

  // Floating turtle mascot comments
  const mascotReactions = {
    default: '🐢 Ready to explore?',
    thinking: '🐢 Hmm, checking your data...',
    celebrating: '🐢 Welcome back, friend!',
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMascotPose('thinking');
    
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));
    
    setIsLoading(false);
    setMascotPose('celebrating');
    onLogin?.(email, password);
  };

  // Theme-specific colors (neumorphic palette)
  const themes = {
    light: {
      bg: '#f5f7fa',
      surface: '#ffffff',
      shadow: 'rgba(163, 177, 198, 0.15)',
      shadowInset: 'rgba(255, 255, 255, 0.5)',
      text: '#1a202c',
      textSecondary: '#718096',
      accent: '#2d9d7f', // Cape Town Table Mountain orange-teal
      accentLight: '#7dd3c0',
      input: '#e2e8f0',
      inputBorder: '#cbd5e0',
    },
    dark: {
      bg: '#1a202c',
      surface: '#2d3748',
      shadow: 'rgba(0, 0, 0, 0.3)',
      shadowInset: 'rgba(255, 255, 255, 0.1)',
      text: '#e2e8f0',
      textSecondary: '#a0aec0',
      accent: '#7dd3c0',
      accentLight: '#a8e6d7',
      input: '#4a5568',
      inputBorder: '#718096',
    },
    'high-contrast': {
      bg: '#ffffff',
      surface: '#ffffff',
      shadow: 'none',
      shadowInset: 'none',
      text: '#000000',
      textSecondary: '#000000',
      accent: '#ff6b35', // Cape Town orange (high contrast)
      accentLight: '#ff6b35',
      input: '#ffffff',
      inputBorder: '#000000',
    },
  };

  const colors = themes[theme];

  // Neumorphic shadow styling
  const shadowStyle = {
    boxShadow:
      theme === 'high-contrast'
        ? `2px 2px 0 ${colors.inputBorder}`
        : `14px 14px 20px ${colors.shadow}, -5px -5px 15px ${colors.shadowInset}`,
  };

  const insetShadowStyle = {
    boxShadow:
      theme === 'high-contrast'
        ? `inset 1px 1px 0 ${colors.inputBorder}`
        : `inset 2px 2px 5px ${colors.shadow}, inset -2px -2px 5px ${colors.shadowInset}`,
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        background: colors.bg,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '20px',
        fontFamily: '"Segoe UI", Roboto, sans-serif',
        color: colors.text,
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Background gradient (subtle) */}
      {theme === 'dark' && (
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'radial-gradient(circle at 20% 50%, rgba(45, 157, 127, 0.1) 0%, transparent 50%)',
            pointerEvents: 'none',
          }}
        />
      )}

      {/* Mascot peeks from top-right corner */}
      {showMascot && (
        <div
          style={{
            position: 'absolute',
            top: '20px',
            right: '30px',
            opacity: 0.9,
            transition: 'transform 0.3s ease',
          }}
        >
          {/* Floating turtle icon (placeholder) */}
          <div
            style={{
              fontSize: '64px',
              animation: 'float 3s ease-in-out infinite',
            }}
          >
            🐢
          </div>
          <p
            style={{
              fontSize: '12px',
              color: colors.accent,
              marginTop: '8px',
              fontWeight: 600,
              textAlign: 'center',
            }}
          >
            {mascotReactions[mascotPose as keyof typeof mascotReactions]}
          </p>
        </div>
      )}

      {/* Main card container */}
      <div
        style={{
          width: '100%',
          maxWidth: '420px',
          padding: '48px 40px',
          background: colors.surface,
          borderRadius: '24px',
          ...shadowStyle,
          position: 'relative',
          zIndex: 10,
        }}
      >
        {/* Header */}
        <div style={{ marginBottom: '32px', textAlign: 'center' }}>
          <h1
            style={{
              fontSize: '28px',
              fontWeight: 700,
              marginBottom: '8px',
              letterSpacing: '-0.5px',
            }}
          >
            Welcome Back
          </h1>
          <p
            style={{
              fontSize: '14px',
              color: colors.textSecondary,
              margin: 0,
            }}
          >
            Cape Town GIS Platform
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit}>
          {/* Email input */}
          <div style={{ marginBottom: '20px' }}>
            <label
              style={{
                display: 'block',
                fontSize: '13px',
                fontWeight: 600,
                marginBottom: '8px',
                color: colors.text,
              }}
            >
              Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              required
              style={{
                width: '100%',
                padding: '14px 16px',
                fontSize: '14px',
                border: `2px solid ${colors.inputBorder}`,
                borderRadius: '12px',
                background: colors.input,
                color: colors.text,
                ...insetShadowStyle,
                boxSizing: 'border-box',
                outline: 'none',
                transition: 'all 0.3s ease',
              }}
              onFocus={(e) => {
                if (theme !== 'high-contrast') {
                  e.currentTarget.style.borderColor = colors.accent;
                }
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = colors.inputBorder;
              }}
            />
          </div>

          {/* Password input */}
          <div style={{ marginBottom: '28px' }}>
            <label
              style={{
                display: 'block',
                fontSize: '13px',
                fontWeight: 600,
                marginBottom: '8px',
                color: colors.text,
              }}
            >
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              style={{
                width: '100%',
                padding: '14px 16px',
                fontSize: '14px',
                border: `2px solid ${colors.inputBorder}`,
                borderRadius: '12px',
                background: colors.input,
                color: colors.text,
                ...insetShadowStyle,
                boxSizing: 'border-box',
                outline: 'none',
                transition: 'all 0.3s ease',
              }}
              onFocus={(e) => {
                if (theme !== 'high-contrast') {
                  e.currentTarget.style.borderColor = colors.accent;
                }
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = colors.inputBorder;
              }}
            />
          </div>

          {/* Primary button (extruded, pressable) */}
          <button
            type="submit"
            disabled={isLoading}
            style={{
              width: '100%',
              padding: '14px 16px',
              fontSize: '15px',
              fontWeight: 700,
              background: colors.accent,
              color: '#ffffff',
              border: 'none',
              borderRadius: '12px',
              cursor: isLoading ? 'not-allowed' : 'pointer',
              ...(isLoading
                ? { opacity: 0.8, ...insetShadowStyle }
                : { ...shadowStyle }),
              transition: 'all 0.2s ease',
              textTransform: 'uppercase',
              letterSpacing: '0.5px',
              position: 'relative',
            }}
            onMouseEnter={(e) => {
              if (!isLoading && theme !== 'high-contrast') {
                e.currentTarget.style.transform = 'translateY(-2px)';
              }
            }}
            onMouseLeave={(e) => {
              if (!isLoading && theme !== 'high-contrast') {
                e.currentTarget.style.transform = 'translateY(0)';
              }
            }}
          >
            {isLoading ? 'Signing In...' : 'Login'}
          </button>
        </form>

        {/* Footer links */}
        <div
          style={{
            marginTop: '24px',
            textAlign: 'center',
            fontSize: '13px',
          }}
        >
          <a
            href="#"
            style={{
              color: colors.accent,
              textDecoration: 'none',
              fontWeight: 600,
            }}
          >
            Forgot password?
          </a>
          <span style={{ color: colors.textSecondary, margin: '0 8px' }}>•</span>
          <a
            href="#"
            style={{
              color: colors.accent,
              textDecoration: 'none',
              fontWeight: 600,
            }}
          >
            Sign up
          </a>
        </div>
      </div>

      {/* CSS animations */}
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }

        @media (prefers-reduced-motion: reduce) {
          * {
            animation: none !important;
            transition: none !important;
          }
        }
      `}</style>
    </div>
  );
};

export default LoginScreen;
