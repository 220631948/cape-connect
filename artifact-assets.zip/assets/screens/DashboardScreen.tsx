/**
 * DashboardScreen.tsx
 * The high-fidelity "Midnight Crayon" Dashboard for CapeTown GIS Hub.
 * Features: Neomorphic panels, crayon accents, and a Data Turtle HUD.
 */
import React from 'react';
import { CrayonButton } from '../components/CrayonButton';
import { DataSourceBadge } from '../components/DataSourceBadge';

export const DashboardScreen: React.FC = () => {
  return (
    <div className="flex h-screen w-full bg-[#0A0A0F] text-[#F0F0F5] overflow-hidden">
      {/* --- NEOMORPHIC SIDEBAR --- */}
      <aside className="w-80 flex-shrink-0 bg-[#12121A] border-r border-[#2A2A3A] p-6 flex flex-col gap-8 shadow-[10px_0_30px_rgba(0,0,0,0.5)] z-20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#5B8DEF] shadow-[0_0_20px_#5B8DEF/40] flex items-center justify-center">
             {/* Simple Logo Doodle */}
             <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="currentColor">
               <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
             </svg>
          </div>
          <h1 className="text-xl font-bold tracking-tight">CapeGIS Hub</h1>
        </div>

        <nav className="flex flex-col gap-4">
          <h2 className="text-[#6B6B80] text-xs font-bold uppercase tracking-widest">Property Layers</h2>
          <div className="flex flex-col gap-2">
            {['Cadastral Parcels', 'Zoning Overlays', 'Valuation 2022', 'Suburb Boundaries'].map((layer) => (
              <label key={layer} className="flex items-center gap-3 p-3 rounded-lg bg-[#1A1A26] border border-transparent hover:border-[#5B8DEF]/30 transition-all cursor-pointer group">
                <input type="checkbox" className="accent-[#5B8DEF] w-4 h-4" />
                <span className="text-sm group-hover:text-white transition-colors">{layer}</span>
              </label>
            ))}
          </div>
        </nav>

        <div className="mt-auto">
          {/* --- DATA TURTLE HUD (Talph-Fix) --- */}
          <div className="bg-[#1A1A26] p-4 rounded-xl border border-[#2A2A3A] shadow-inner relative overflow-hidden group">
            <div className="absolute top-0 left-0 w-1 h-full bg-[#A3E635] shadow-[0_0_10px_#A3E635]" />
            <div className="flex gap-3 items-start">
              <div className="text-2xl">🐢</div>
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-bold text-[#A3E635] uppercase tracking-tighter">Turtle Tips</span>
                <p className="text-xs text-[#A0A0B8] italic leading-relaxed">
                  "I found a squishy parcel! It's zoned for 'Happy Trees'! 🌳"
                </p>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* --- MAP ENGINE VIEWPORT --- */}
      <main className="relative flex-grow bg-[#000000] overflow-hidden">
        {/* MapLibre Placeholder Overlay */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
          <div className="text-9xl font-black text-[#F0F0F5]">MAP CONTENT</div>
        </div>
        
        {/* --- MAP CONTROLS (Floating Neomorphic) --- */}
        <div className="absolute top-6 right-6 flex flex-col gap-2">
           <CrayonButton size="sm" accent="blue" className="w-10 h-10 flex items-center justify-center p-0 text-xl font-bold">+</CrayonButton>
           <CrayonButton size="sm" accent="blue" className="w-10 h-10 flex items-center justify-center p-0 text-xl font-bold">-</CrayonButton>
           <CrayonButton size="sm" accent="purple" className="w-10 h-10 flex items-center justify-center p-0">🧭</CrayonButton>
        </div>

        {/* --- BOTTOM DASHBOARD METRICS --- */}
        <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between pointer-events-none">
          <div className="flex flex-col gap-3 pointer-events-auto">
            <div className="bg-[#12121A]/80 backdrop-blur-md p-4 rounded-xl border border-[#2A2A3A] shadow-2xl flex flex-col gap-1 min-w-[200px]">
               <span className="text-[#6B6B80] text-[10px] uppercase font-bold tracking-widest">Active Parcel</span>
               <span className="text-lg font-bold">Erf 123, Cape Town</span>
               <DataSourceBadge source="CoCT GIS" year="2022" status="LIVE" />
            </div>
          </div>

          <div className="flex gap-2 pointer-events-auto">
             <CrayonButton accent="green">Analyze Vibe</CrayonButton>
             <CrayonButton accent="coral">Report Bug 🐛</CrayonButton>
          </div>
        </div>
      </main>
    </div>
  );
};
