# INTEGRATION GUIDE: FROM ASSETS TO APP
**DATE:** Tuesday, March 10, 2026
**STATUS:** [✅ VERIFIED] - TECH-STACK ALIGNED

Since the `app/` directory is "future" (as per `CLAUDE.md`), you can integrate these neomorphic components once the Next.js scaffold is ready.

## 1. PRE-REQUISITES
- Next.js 15 (App Router)
- React 19
- Tailwind CSS 4 (with CSS Variable support)

## 2. COPY-PASTE PATHS

| Component | Target Location |
| :--- | :--- |
| **Icons** | `public/assets/icons/` |
| **Common Components** | `app/src/components/common/` |
| **Screens / Pages** | `app/dashboard/page.tsx` |

## 3. USAGE EXAMPLES

### [Crayon Button]
```tsx
import { CrayonButton } from '@/components/common/CrayonButton';

<CrayonButton accent="green" size="lg" onClick={handleLiveSync}>
  Synchronize LIVE Data
</CrayonButton>
```

### [Data Source Badge]
```tsx
import { DataSourceBadge } from '@/components/common/DataSourceBadge';

<DataSourceBadge source="CoCT GIS" year="2022" status="LIVE" />
```

## 4. DESIGN TOKENS (TAILWIND 4)
Ensure your `globals.css` includes the following variables from `docs/ux/design-system.md`:
```css
:root {
  --bg-primary: #0A0A0F;
  --bg-secondary: #12121A;
  --bg-tertiary: #1A1A26;
  --accent-blue: #5B8DEF;
  --accent-green: #4ECDC4;
  --accent-amber: #FFB347;
  --accent-orange: #FB923C;
}
```

---
*"I want to push the bouncy buttons in the real app now!"* — Talph Wiggum
