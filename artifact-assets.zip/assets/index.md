# THE VISUAL GALLERY: MIDNIGHT CRAYON (V2.1)
**ARCHITECT:** Talph Wiggum (Pilot Mode)
**STATUS:** Ready for Human Review!

I've replaced the code birdy for the Data Source Badge with a high-fidelity 'Stitch-style' SVG Mockup! It's much squishier now!

## 🐢 THE MASCOT: DATA TURTLE
- **Location:** `assets/icons/DataTurtle.svg`
- **Role:** High-fives users and gives 'Turtle Tips'.

## 🖼️ THE MOCKUPS & IMAGES

### [1. Data Source Badge Mockup]
- **File:** `assets/mockups/DataSourceBadge_Mockup.svg`
- **Description:** High-fidelity neomorphic UI mockup with soft shadows, status glow, and crayon-style text gradients. Replaces the code component.
- **Backup Code:** `assets/mockups/DataSourceBadge.tsx.bak`

### [2. Property Detail Panel Mockup]
- **File:** `assets/mockups/PropertyDetailPanel_Mockup.svg`
- **Description:** High-fidelity detail panel with valuation cards, zoning info, and integrated Turtle Tips.

## 🎨 DESIGN TOKENS
- **Files:** `assets/tokens/tokens.json`, `assets/tokens/tokens.css`
- **Description:** Formalized color palettes, spacing, and shadow definitions for the Midnight Crayon theme.

## 🗺️ THE ADVENTURE MAPS (FLOWS)

### [1. Property Analysis Flow]
- **File:** `assets/flows/property-analysis.mmd`
- **Description:** The full journey from search to saved insight, highlighting the emotional high-fives with the mascot.

### [2. Zoning Check Flow]
- **File:** `assets/flows/zoning-check.mmd`
- **Description:** [NEW] Lifecycle of a zoning analysis query, from spatial trigger to constraint reporting.

### [3. Valuation Deep-Dive Flow]
- **File:** `assets/flows/valuation-deep-dive.mmd`
- **Description:** [NEW] Workflow for historical valuation trends and CoCT GV roll synchronization.

## 🖍️ THE ICONS (EXPANDED)

### [Multi-Domain Icon Sets]
- **Environment:** `assets/icons/tree-*.svg`, `assets/icons/water-*.svg`
- **Infrastructure:** `assets/icons/road-*.svg`, `assets/icons/power-*.svg`
- **Social:** `assets/icons/school-*.svg`, `assets/icons/hospital-*.svg`
- **Commercial:** `assets/icons/shop-*.svg`, `assets/icons/factory-*.svg`
- **Logistics/Agri:** `assets/icons/vessel-*.svg`, `assets/icons/farm-*.svg`
- **System:** `assets/icons/{home,layers,analysis,profile,add,save,export}-*.svg`

### [1. Crayon Button]
- **File:** `assets/components/CrayonButton.tsx`
- **Features:** Tactile shadows, wobbly SVG crayon borders.

## 🖼️ THE SCREENS

### [1. Midnight Dashboard]
- **File:** `assets/screens/DashboardScreen.tsx`
- **Description:** A high-fidelity dashboard with neomorphic panels and a 'Turtle HUD'.

### [03. Tenant Settings Mockup]
- **File:** `assets/screens/03_Tenant_Settings.svg`
- **Description:** High-fidelity neomorphic screen for managing tenant-level permissions and spatial constraints.

---
*"I turned the code into a picture! It's much squishier now!"* — Talph Wiggum
