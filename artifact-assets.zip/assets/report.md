# Visual System Context: CapeTown GIS Hub (capegis)

## 1. Project Overview
* **App Name:** CapeTown GIS Hub
* **Core Purpose:** A professional multi-tenant, white-label PWA for spatial property intelligence, focusing on Cape Town and the Western Cape.
* **Target Audience:** Property professionals, developers, and municipal stakeholders looking for accessible but rigorous spatial data.

## 2. Branding & Aesthetic Mandate
* **Global Style:** Whimsical Neumorphism (v2.1).
* **Vibe:** "Midnight Crayon" — A deep-sea, near-black dashboard base that feels tactical and solid, accented by hand-drawn "crayon" doodles and soft, squishy interactive surfaces.
* **Lighting:** Dual-source neomorphic lighting. Top-left subtle border highlights (#2A2A3A) and bottom-right soft, deep shadows (#000000) to create a "pressed-in" or "raised-clay" feel.

## 3. Color Palette (Hex Values)
* **Background / Canvas:** `#0A0A0F` - The deep midnight base.
* **Primary Surface (Raised):** `#12121A` - Tactical neomorphic cards and sidebars.
* **Primary Brand Color:** `#5B8DEF` - "Accent Blue" for active nav, primary buttons, and focus.
* **Secondary/Accents:** 
    - `#FF6B6B` (Coral) - Alerts/Bugs
    - `#4ECDC4` (Green) - LIVE Status/Success
    - `#FFB347` (Amber) - CACHED Status
    - `#A3E635` (Lime) - Environmental/Turtle Tips
* **Text/Ink:** `#F0F0F5` (Primary), `#A0A0B8` (Secondary), `#6B6B80` (Muted).
* **Shadow Base:** `#000000` (Outer), `#050508` (Inner).
* **Highlight Base:** `#2A2A3A` (Borders), `#1A1A26` (Raised surface highlights).

## 4. Icon Inventory & Categories
**Style constraints:** Soft rounded caps, slight inner glow, medium stroke weight, neomorphic clay forms.
* **Navigation:** Home (plump house), Layers (stacked tiles), Analysis (magnifying glass with a wiggle), Profile (squishy silhouette).
* **Actions:** Add Layer (plump plus), Save View (neomorphic cloud), Export (bouncy arrow).
* **Feedback/Decor:** Data Turtle (neomorphic mascot), Sparkle (hand-drawn star), Live Pulse (glowing dot).

## 5. Screen Inventory (Context for Tokens)
* `01_Dashboard_Primary` - The main map engine with neomorphic sidebars and floating Turtle HUD.
* `02_Property_Detail` - Detailed property cards with "Valuation 2022" crayon charts.
* `03_Tenant_Settings` - White-label configuration with tactile toggles and sliders.

## 6. User Journeys to Diagram (The "Adventure Maps")
* **Flow 1: First-Run Onboarding**
    * *Path:* Landing -> Tenant Login -> Regional Selection -> Dashboard Intro.
    * *Vibe:* A journey from the deep-sea dark to the glowing map.
* **Flow 2: Property Deep-Dive (Primary Loop)**
    * *Path:* Map Search -> Select Parcel -> View Erf Data -> High-five Data Turtle -> Save Result.
    * *Vibe:* The rewarding core engine. Highlight the parcel "High-five" as the climax.
* **Flow 3: Offline Sync (The "Oops" Path)**
    * *Path:* Live Data Lost -> "Don't Panic" Mascot -> Switch to Cached/Mock -> Re-sync Successful.
    * *Vibe:* Reassuring and soft. The offline mascot should look cozy, not scary.
