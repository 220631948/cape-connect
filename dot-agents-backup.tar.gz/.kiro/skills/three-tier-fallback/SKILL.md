# Skill: three-tier-fallback

## Trigger
When implementing or reviewing any component or hook that fetches external or database data for display on the map or dashboard.

## Description
Implements the mandatory LIVE → CACHED → MOCK fallback chain (CLAUDE.md Rule 2). Ensures no data component ever renders blank or throws — it always falls back gracefully and displays the correct source badge.

## Steps

1. Confirm a mock file exists at `public/mock/<layer>.geojson`. If not, create a minimal valid GeoJSON FeatureCollection for the layer before proceeding.

2. Structure the data fetch using `useLiveData` hook (or replicate its pattern for new hooks):
   ```ts
   // 1. LIVE — attempt real API / Martin tile source
   // 2. CACHED — query Supabase api_cache table (TTL-aware)
   // 3. MOCK — load from public/mock/<layer>.geojson
   ```

3. Track the active tier in state: `'LIVE' | 'CACHED' | 'MOCK'`.

4. Pass the tier to the `SourceBadge` component on every data-displaying component:
   ```tsx
   <SourceBadge source="City of Cape Town" year={2024} status={tier} />
   ```
   The badge must be visible without hovering — this is non-negotiable (CLAUDE.md Rule 1).

5. On LIVE failure: log the error to console (and Sentry if DSN present), then attempt CACHED.
   On CACHED failure or cache miss: fall through to MOCK silently.
   MOCK must never fail — if it does, the mock file is broken and must be fixed first.

6. For API routes that feed this data: confirm the route returns a consistent shape for all three tiers so the consumer doesn't need to branch on tier.

7. Run `npm test` to confirm no regressions in existing fallback tests.

## Constraints
- Never remove or skip the MOCK tier — it is the last-resort guarantee
- `public/mock/` files are read-only reference data — do not generate them dynamically
- The `SourceBadge` must reflect the actual tier in use, not a hardcoded value
- Turf.js is for client-side analysis of < 10k features only — above that, delegate to PostGIS via API
