# Skill: rbac-check

## Trigger
When adding or modifying any API route, component, or hook that gates behaviour by user role.

## Description
Validates that RBAC enforcement is correctly layered: application-layer role check → tenant-mismatch check → Supabase query. Catches common gaps like JWT-only role checks, missing tenant isolation, and exposed admin UI.

## Steps

1. Identify the role(s) required for the operation being implemented.

2. Confirm the role is read from the session profile (via `src/lib/auth/roles.ts` or `admin-session.ts`), not from raw JWT claims.

3. For any route under `src/app/api/admin/`:
   - Check that role is verified before the Supabase query executes
   - Check that a tenant-mismatch guard is present when the operation targets another user's record
   - Confirm the error response is `403` with `"Forbidden: <specific reason>"`

4. For UI components in `src/components/admin/`:
   - Confirm admin-only elements (`UserManagementPanel`, `ImpersonationModal`, admin tabs) are conditionally rendered using the session profile role — not a client-side JWT decode
   - Guest-mode restrictions must hide: property details, risk layers, export controls, saved searches

5. For impersonation paths (`src/app/api/admin/impersonate/`, `src/lib/auth/impersonation-token.ts`):
   - Verify: no self-impersonation, no PLATFORM_ADMIN impersonation, TENANT_ADMIN blocked from cross-tenant
   - Confirm audit log entry is written on every impersonation event

6. Run the existing role tests: `npm test -- src/lib/auth/__tests__/roles.test.ts`

## Constraints
- Never rely on `NEXT_PUBLIC_` env vars for role decisions
- Role hierarchy is fixed: `GUEST → VIEWER → ANALYST → POWER_USER → TENANT_ADMIN → PLATFORM_ADMIN`
- Do not introduce a new role without updating `src/lib/auth/roles.ts` and the RLS policies in `supabase/migrations/`
