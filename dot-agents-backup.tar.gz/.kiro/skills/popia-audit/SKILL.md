# Skill: popia-audit

## Trigger
When asked to audit POPIA compliance, before any PR touching personal data files, or when adding a new table/field that stores user or location data.

## Description
Scans the affected files and migration for POPIA annotation presence, RLS coverage, and audit log wiring. Produces a pass/fail checklist — does not auto-fix, flags gaps for human review.

## Steps

1. Identify all files in scope that handle personal data. Personal data fields in this project:
   - `email`, `user_id`, `tenant_id`, `role`, `full_name`, `avatar_url` (table: `profiles`)
   - `invited_email`, `token` (table: `tenant_invitations`)
   - `geometry` / location data tied to a user or parcel
   - Any field in `audit_log`, `saved_searches`, `favourites`, `valuation_data`

2. For each TypeScript file in scope, check:
   - [ ] `@popia` annotation block present at the top with all 5 fields filled (Data handled, Purpose, Lawful basis, Retention, Subject rights)
   - [ ] No cross-tenant data leak: queries filter by `tenant_id` or rely on RLS

3. For each migration file in scope (`supabase/migrations/*.sql`), check:
   - [ ] `ALTER TABLE ... ENABLE ROW LEVEL SECURITY` present for any new table
   - [ ] At least one RLS policy scoped to `tenant_id` or `auth.uid()`
   - [ ] `SECURITY DEFINER` functions include `SET search_path = public, pg_temp`

4. For role-change, impersonation, and export operations, check:
   - [ ] `audit_log` insert is present in the code path
   - [ ] Log entry includes: `user_id`, `tenant_id`, `action`, `timestamp`, `metadata`

5. Report findings as a checklist. Mark each item ✅ PASS or ❌ FAIL with the file and line reference.

6. Do not auto-apply fixes. List remediation steps for each ❌ item.

## Constraints
- This skill is read-only — it audits, it does not modify files
- Scope to the files explicitly provided or changed in the current task
- If a new table is added without RLS, escalate immediately — this is a P0 violation per CLAUDE.md Rule 4
