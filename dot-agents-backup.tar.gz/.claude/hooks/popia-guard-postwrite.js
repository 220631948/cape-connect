#!/usr/bin/env node
/**
 * popia-guard-postwrite.js
 * PostToolUse Write hook — fires after any src/ file is written.
 * Checks: if the file contains personal data field names, it must have a @popia annotation.
 * Exit 0 always (non-blocking warning only).
 */
'use strict';

const fs = require('fs');
const path = require('path');

const filePath = process.argv[2] || process.env.CLAUDE_TOOL_INPUT_FILE_PATH || '';

if (!filePath || !fs.existsSync(filePath)) process.exit(0);

const ext = path.extname(filePath);
if (!['.ts', '.tsx'].includes(ext)) process.exit(0);

const content = fs.readFileSync(filePath, 'utf8');

// Personal data field patterns relevant to this project
const PII_PATTERNS = [
  /\bemail\b/,
  /\buser_id\b/,
  /\btenant_id\b/,
  /\bfull_name\b/,
  /\bavatar_url\b/,
  /\binvited_email\b/,
  /\bprofiles\b/,
  /\baudit_log\b/,
  /\bvaluation_data\b/,
];

const hasPii = PII_PATTERNS.some((re) => re.test(content));
const hasAnnotation = /@popia/i.test(content);

if (hasPii && !hasAnnotation) {
  process.stderr.write(
    `[POPIA-GUARD] ⚠️  ${filePath}\n` +
    `  Personal data fields detected but no @popia annotation found.\n` +
    `  Add the POPIA annotation block at the top of this file (see security.md Rule 5).\n`
  );
}

process.exit(0);
